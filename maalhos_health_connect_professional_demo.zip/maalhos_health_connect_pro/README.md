# Maalhos Health Connect — Management Demo

A responsive, single-file, offline-capable browser prototype in English, Dhivehi, and Bangla. All records, staff roles, clinical content and document entries are fictional.

## Try it
Open `index.html` in Chrome or another modern browser. Use the language dropdown and tabs. Create a fictional appointment in Booking, then switch to Admin to approve or decline it. Doctor notes and appointments persist in this browser's localStorage only. Use Reset demo to clear them.

## Publish a static demo
Upload `index.html` to a GitHub repository and enable GitHub Pages (Settings → Pages → Deploy from branch). Share the URL only as a **demo**, not an official health centre service.

## Security and limitations
No server, accounts, authentication, authorization, real booking, real patient record management, document uploads, encryption at rest, or audit logging. The doctor/admin tabs are publicly accessible in this demo. Never enter actual patient information, private documents, credentials or personal health data. Do not use it for clinical care. Dhivehi wording is draft and should be reviewed by a native speaker before public release.

## Production roadmap
Obtain written health centre authorization; define data ownership and permissions; conduct a privacy/security review under applicable Maldives requirements; implement a protected backend, strong authentication, per-role access, audit logging, encrypted storage, retention policy, backups, secure appointment scheduling and clinical governance. Only then consider a production Android AAB and Play Store submission.
